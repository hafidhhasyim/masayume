ALTER TABLE `sliders` ADD `description` text;--> statement-breakpoint
ALTER TABLE `sliders` ADD `image2_url` text;